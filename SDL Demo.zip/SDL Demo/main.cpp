#include <iostream>
#include <SDL2/SDL.h>

// Funciones para usar con SDL

// Reporta un mensaje de error y termina el programa
void SDL_Error(std::string msg) {
    std::cerr << "SDL Error: " << SDL_GetError() << " (" << msg << ")" << std::endl;
    exit(EXIT_FAILURE);
}

// Dibuja un pixel en una superficie/imagen de SDL
void setpixel(SDL_Surface *s, int x, int y, int r, int g, int b) {
    Uint8 *target = (Uint8 *)s->pixels + y * s->pitch + (x << 2);
    *(Uint32 *)target = (r << 16) | (g << 8) | b;
}


int main(int argv, char** args) {
    // Inicializa SDL
    if (SDL_Init(SDL_INIT_VIDEO)) SDL_Error("SDL_Init");

    // Crea una ventana de tamaño 640x480 pixeles en la posición (100,100) de la pantalla
    SDL_Window *win = SDL_CreateWindow("Hello World!", 100, 100, 640, 480, SDL_WINDOW_SHOWN);
    if (win == NULL) SDL_Error("SDL_CreateWindow");

    // Obtiene una referencia a la superficie (imagen) que se muestra en la ventana
    SDL_Surface *frame = SDL_GetWindowSurface(win);
    if (frame == NULL) SDL_Error("SDL_GetWindowSurface");

    // Dibuja un cuadrado con un degradado de colores
    int x, y;
    for (y = 0; y < 256; y++) {
        for (x = 0; x < 256; x++) {
            setpixel(frame, x+100, y+100, x, 255-y, 0);
        }
    }
    SDL_UpdateWindowSurface(win);   // Muestra la imagen en la ventana

    SDL_Delay(2000);    // Espera 2 segundos (2000 ms)

    SDL_DestroyWindow(win); // Cierra la ventana
    SDL_Quit();
    return 0;
}

